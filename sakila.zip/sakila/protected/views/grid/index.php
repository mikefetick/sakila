<?php
/**
 * Created by PhpStorm.
 * User: Mike
 * Date: 9/20/14
 * Time: 5:16 PM
 */
?>
<?php
    $this->widget('zii.widgets.grid.CGridView', array('dataProvider'=>$dataProvider, ) )
?>
